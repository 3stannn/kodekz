---
name: portfolio-skill
description: Thristan Dave Bumagat's Developer Portfolio Skill - Background, projects, tech stack, and experience.
---

# Thristan Dave Bumagat Portfolio Skill

Full-Stack Web Developer & 3rd-year Computer Science student building clean full-stack platforms, bridging frontier AI models with agentic tooling, and architecting relational backends.

## Core Stack
- Frontend: React 19, Tailwind CSS, GSAP, Vite
- Backend & Databases: Node.js, PostgreSQL, Supabase
- AI Agent Systems: Kip Orchestration, Gemini API, Claude Code

## Links
- Website: https://kodekz.vercel.app
- GitHub: https://github.com/kodekz
- Contact: thristandave12@gmail.com
